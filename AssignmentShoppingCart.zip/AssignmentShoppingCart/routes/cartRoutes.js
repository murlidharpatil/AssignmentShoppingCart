const express = require('express');
const Cart = require('../models/Cart');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// Get cart items for the logged-in user
router.get('/', authMiddleware, async (req, res) => {
    try {
        console.log("inside cart get");
        const cart = await Cart.findOne({ userId: req.user.id }).populate("products.productId");

        if (!cart || cart.products.length === 0) {
            return res.status(404).json({ message: "Cart is empty" });
        }

        res.json(cart);
    } catch (error) {
        console.error("Error fetching cart:", error);
        res.status(500).json({ message: "Server error", error });
    }
});

// Add item to cart
router.post('/add', authMiddleware, async (req, res) => {
    try {
        console.log("inside cart add");

        const { productId, quantity } = req.body;
        if (!productId || !quantity) {
            return res.status(400).json({ message: "Product ID and quantity are required" });
        }

        let cart = await Cart.findOne({ userId: req.user.id });

        if (!cart) {
            cart = new Cart({ userId: req.user.id, products: [] });
        }

        if (!cart.products) {
            cart.products = [];
        }

        const existingProduct = cart.products.find(p => p.productId?.toString() === productId);

        if (existingProduct) {
            existingProduct.quantity += quantity; // Increase quantity if product exists
        } else {
            cart.products.push({ productId, quantity });
        }

        await cart.save();
        res.json(cart);
    } catch (error) {
        console.error("Error adding product to cart:", error);
        res.status(500).json({ message: "Server error", error });
    }
});

// Checkout: Return all cart items for the logged-in user
router.post('/checkout', authMiddleware, async (req, res) => {
    try {
        const cart = await Cart.findOne({ userId: req.user.id }).populate("products.productId");

        if (!cart || cart.products.length === 0) {
            return res.status(404).json({ message: "Cart is empty" });
        }

        res.json(cart.products);
    } catch (error) {
        console.error("Checkout error:", error);
        res.status(500).json({ message: "Server error", error });
    }
});

module.exports = router;
