require('dotenv').config();
const express = require('express');
const connectDB = require('./config/db');

const app = express();

connectDB();

app.use(express.json());
console.log('Auth start');
app.use('/api/auth', require('./routes/authRoutes'));
console.log('Auth end');
console.log('products start');
app.use('/api/products', require('./routes/productRoutes'));
console.log('products end');
console.log('cart start');
app.use('/api/cart', require('./routes/cartRoutes'));
console.log('cart end');

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));