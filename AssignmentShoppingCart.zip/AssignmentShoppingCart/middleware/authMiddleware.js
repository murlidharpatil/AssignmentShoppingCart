const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
    const token = req.header("Authorization");
    console.log(token);
    if(!token || !token.startsWith("Bearer ")){
        console.log("No token provided or incorrect format");
        return res.status(401).json({message: "Unauthorized"});
    }
    const tokenvalue = token.split(" ")[1]; // Extract token after "Bearer"
    console.log("Received Token:", token);
    try{
        const decoded = jwt.verify(tokenvalue, process.env.JWT_SECRET);
        console.log("Token Decoded:", decoded);
        req.user = decoded;
        next();

    } catch(error){
        res.status(401).json({message: "Invalid Token"});
    }
};

module.exports = authMiddleware;